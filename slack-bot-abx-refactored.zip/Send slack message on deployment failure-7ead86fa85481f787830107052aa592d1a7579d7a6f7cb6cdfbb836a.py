'''
Script to send a slack message when a request fails 
dgertsch@kovarus.com 
April 2020
'''

import json
import logging
import slack
import requests

logger = logging.getLogger()
logger.setLevel(logging.INFO)

VRAC_API_URL = "https://api.mgmt.cloud.vmware.com"

def handler(context, inputs):
    ''' 
    get vRAC bearer_token
    work around as the context does not contain auth information for this event
    '''
    bearer_token = get_vrac_bearer_token(inputs)
    deployment_name = get_deployment_name(inputs["deploymentId"], bearer_token)

    '''
    Send to slack bot 
    '''
    slack_result = send_message_to_slack(inputs,deployment_name)
    return slack_result

def send_message_to_slack(inputs,deployment_name):
    '''
    Send message to slack bot 
    '''
    SLACK_API_TOKEN = inputs["SLACK_API_TOKEN"]
    SLACK_CHANNEL = inputs["SLACK_CHANNEL"]
    
    logger.info("## Sending message to slack bot ##")
    
    client = slack.WebClient(token=SLACK_API_TOKEN)
    client.chat_postMessage(
      channel=SLACK_CHANNEL,
      blocks=[
        {
          "type": "section",
          "text": {
            "type": "mrkdwn",
            "text": f"*DEPLOYMENT FAILED: *\nDeployment Name: " + deployment_name
            }
        },
		{
			"type": "section",
			"text": {
				"type": "mrkdwn",
				"text": "Direct link to broken deployment. "
			},
			"accessory": {
				"type": "button",
				"text": {
					"type": "plain_text",
					"text": "Deployment URL",
				},
				"url": "https://www.mgmt.cloud.vmware.com/deployment-ui/#/deployment/" + inputs['deploymentId']
			}
		},          
        {
          "type": "section",
          "fields": [
            {
                "type": "mrkdwn",
                "text": f"*Failure message: *\n{inputs['failureMessage']}"
            }
          ]
        },
        {
          "type": "section",
          "fields": [
            {
				"type": "mrkdwn",
				"text": f"*Requested by: *\n{inputs['userName']}"
			},            
            {
              "type": "mrkdwn",
              "text": f"*Project: *\n{inputs['projectName']}"
            }
          ]
        }
      ]
    )

def get_vrac_bearer_token(inputs):
    url = VRAC_API_URL + "/iaas/api/login"
    payload = { "refreshToken": inputs["VRAC_REFRESH_TOKEN"] }
    result = requests.post(url = url, json = payload)
    result_data = result.json()
    bearer_token = result_data["token"]
    return bearer_token
    
def get_deployment_name(id, bearer_token):
    url = VRAC_API_URL + "/deployment/api/deployments/" + id 
    headers = {"Authorization": "Bearer " + bearer_token}
    result = requests.get(url = url, headers=headers)
    logging.info(result)
    result_data = result.json()
    deployment_name = result_data["name"]
    logging.info("### deployment name is %s ", deployment_name)
    return deployment_name

